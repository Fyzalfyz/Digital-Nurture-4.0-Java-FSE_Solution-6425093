/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.designpatterns;

/**
 *
 * @author Fyzal
 */
public class DesignPatterns {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
